# OrganizationCreateEventPayload

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**organization** | [**Organization**](Organization.md) |  |  [optional]
