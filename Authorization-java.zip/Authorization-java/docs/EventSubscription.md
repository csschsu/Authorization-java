# EventSubscription

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | Id of the listener | 
**callback** | **String** | The callback being registered. | 
**query** | **String** | additional data to be passed |  [optional]
