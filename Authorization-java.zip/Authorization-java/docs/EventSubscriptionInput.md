# EventSubscriptionInput

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**callback** | **String** | The callback being registered. | 
**query** | **String** | additional data to be passed |  [optional]
