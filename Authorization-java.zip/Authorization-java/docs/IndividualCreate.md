# IndividualCreate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aristocraticTitle** | **String** | e.g. Baron, Graf, Earl,… |  [optional]
**birthDate** | [**OffsetDateTime**](OffsetDateTime.md) | Birth date |  [optional]
**countryOfBirth** | **String** | Country where the individual was born |  [optional]
**deathDate** | [**OffsetDateTime**](OffsetDateTime.md) | Date of death |  [optional]
**familyName** | **String** | Contains the non-chosen or inherited name. Also known as last name in the Western context | 
**familyNamePrefix** | **String** | Family name prefix |  [optional]
**formattedName** | **String** | A fully formatted name in one string with all of its pieces in their proper place and all of the necessary punctuation. Useful for specific contexts (Chinese, Japanese, Korean,…) |  [optional]
**fullName** | **String** | Full name flatten (first, middle, and last names) |  [optional]
**gender** | **String** | Gender |  [optional]
**generation** | **String** | e.g.. Sr, Jr, III (the third),… |  [optional]
**givenName** | **String** | First name of the individual | 
**legalName** | **String** | Legal name or birth name (name one has for official purposes) |  [optional]
**location** | **String** | Temporary current location od the individual (may be used if the individual has approved its sharing) |  [optional]
**maritalStatus** | **String** | Marital status (married, divorced, widow ...) |  [optional]
**middleName** | **String** | Middles name or initial |  [optional]
**nationality** | **String** | Nationality |  [optional]
**placeOfBirth** | **String** | Reference to the place where the individual was born |  [optional]
**preferredGivenName** | **String** | Contains the chosen name by which the individual prefers to be addressed. Note: This name may be a name other than a given name, such as a nickname |  [optional]
**title** | **String** | Useful for titles (aristocratic, social,...) Pr, Dr, Sir, ... |  [optional]
**contactMedium** | [**List&lt;ContactMedium&gt;**](ContactMedium.md) |  |  [optional]
**creditRating** | [**List&lt;PartyCreditProfile&gt;**](PartyCreditProfile.md) |  |  [optional]
**disability** | [**List&lt;Disability&gt;**](Disability.md) |  |  [optional]
**externalReference** | [**List&lt;ExternalReference&gt;**](ExternalReference.md) |  |  [optional]
**individualIdentification** | [**List&lt;IndividualIdentification&gt;**](IndividualIdentification.md) |  |  [optional]
**languageAbility** | [**List&lt;LanguageAbility&gt;**](LanguageAbility.md) |  |  [optional]
**otherName** | [**List&lt;OtherNameIndividual&gt;**](OtherNameIndividual.md) |  |  [optional]
**partyCharacteristic** | [**List&lt;Characteristic&gt;**](Characteristic.md) |  |  [optional]
**relatedParty** | [**List&lt;RelatedParty&gt;**](RelatedParty.md) |  |  [optional]
**skill** | [**List&lt;Skill&gt;**](Skill.md) |  |  [optional]
**status** | [**IndividualStateType**](IndividualStateType.md) |  |  [optional]
**taxExemptionCertificate** | [**List&lt;TaxExemptionCertificate&gt;**](TaxExemptionCertificate.md) |  |  [optional]
**_atBaseType** | **String** | When sub-classing, this defines the super-class |  [optional]
**_atSchemaLocation** | **String** | A URI to a JSON-Schema file that defines additional attributes and relationships |  [optional]
**_atType** | **String** | When sub-classing, this defines the sub-class entity name |  [optional]
