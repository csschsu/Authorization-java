# OrganizationStateType

## Enum

* `INITIALIZED` (value: `"initialized"`)
* `VALIDATED` (value: `"validated"`)
* `CLOSED` (value: `"closed"`)
