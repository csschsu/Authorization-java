# IndividualStateType

## Enum

* `INITIALIZED` (value: `"initialized"`)
* `VALIDATED` (value: `"validated"`)
* `DECEADED` (value: `"deceaded"`)
