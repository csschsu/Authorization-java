# IndividualCreateEventPayload

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**individual** | [**Individual**](Individual.md) |  |  [optional]
